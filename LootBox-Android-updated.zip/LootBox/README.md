# LootBox (Android)

Kotlin + XML (ViewBinding). A download manager (direct links + YouTube / Facebook / Instagram via yt-dlp): paste a link, download with pause / resume / cancel, see finished files in a library, play them in the built-in player, change a few settings.

## Screens
- Home: logo, URL box with Paste button, Download, latest download card
- Downloads: active (progress, speed, pause/resume, cancel), completed, failed (Retry)
- Library: grid of finished files (thumbnail + length), Open (in-app player) / Share / Rename / Delete
- Settings: video quality, simultaneous downloads, Wi-Fi only, notifications, dark theme, app update

## Built-in player
Videos and audio open inside LootBox (ExoPlayer) with:
- Play / Pause
- Seek ±10 seconds
- Progress bar + time
- Fullscreen immersive mode

## YouTube / Facebook / Instagram
Links from these sites go through yt-dlp (library `youtubedl-android`, same engine as Seal).
Other web-page links are also tried with yt-dlp. Direct file links use the plain HTTP downloader.
Private / login-only videos cannot be downloaded. The APK gets about 30-50 MB bigger (Python + FFmpeg).

## Folder structure
```
build.gradle.kts, settings.gradle.kts, gradle.properties
.github/workflows/build-apk.yml      GitHub Actions: builds the debug APK + publishes Release
app/build.gradle.kts                 module config + dependencies (incl. Media3 / ExoPlayer)
app/src/main/AndroidManifest.xml
app/src/main/java/com/siraanabin/lootbox/
  MainActivity.kt                    bottom navigation + share-intent handling
  HomeFragment.kt  DownloadsFragment.kt  LibraryFragment.kt  SettingsFragment.kt
  PlayerActivity.kt                  built-in video / audio player
  DownloadService.kt                 foreground service: HTTP + yt-dlp download
  DownloadStore.kt  Model.kt         download list (SharedPreferences)
  DownloadsAdapter.kt  LibraryAdapter.kt  Thumbs.kt  Util.kt  Prefs.kt  LootBoxApp.kt  Updater.kt
app/src/main/res/                    layouts, dark lime theme, icons, logo
```

## Build
- GitHub: push to `main`, then open Actions -> "Build LootBox APK" -> Artifacts.
  A Release is also published automatically so the in-app updater can find it.
- Android Studio: open this folder (File > Open), let Gradle sync, press Run.
  (No gradle wrapper is included; Android Studio can create one, or use `gradle assembleDebug`.)

## Notes
- minSdk 29 (Android 10+). Files are saved to Downloads/LootBox with MediaStore, no storage permission needed.
- Share a link from a browser to LootBox and it fills the URL box.
- Change `applicationId` in app/build.gradle.kts if you need your old package name.

## Updates (friends get them automatically)
- Every push to `main` builds the APK and publishes it as a GitHub Release (`build-N`).
- The version number is the Actions run number, so no manual version bump is needed.
- The app checks the latest Release on start (and in Settings > App update) and offers to install it.
- `app/debug.keystore` is a fixed signing key, so a new APK installs over the old one.
  (First time only: uninstall the older LootBox that was signed with a different key.)
- Settings > Update download engine updates yt-dlp without a new APK. Use it when YouTube stops working.
- The repo must stay public for the in-app update check.

## Theme
Dark lime design inspired by the LootBox prototype:
- Background `#0B0D0B`
- Cards `#121712`
- Accent `#C8F26B`
